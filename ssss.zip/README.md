
Professional NestJS Backend

Stack:
- NestJS
- Fastify
- Socket.io realtime
- Redis pub/sub

Modules:
Auth
Users
Orders

Run:

npm install
npm run start:dev

Server:
http://localhost:3000

Socket event:

notify
