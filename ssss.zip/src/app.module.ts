
import { Module } from '@nestjs/common';
import { AuthModule } from './modules/auth/auth.module';
import { UsersModule } from './modules/users/users.module';
import { OrdersModule } from './modules/orders/orders.module';
import { RealtimeGateway } from './realtime/gateway';
// import { RedisService } from './redis/redis.service';
import { PaymentsModule } from './modules/payments/payments.module';

@Module({
  imports: [AuthModule, UsersModule, OrdersModule, PaymentsModule],
  // providers: [RealtimeGateway, RedisService],
  providers: [RealtimeGateway],
})
export class AppModule {}
