
import { WebSocketGateway, SubscribeMessage, WebSocketServer, MessageBody } from '@nestjs/websockets';
import { Server } from 'socket.io';

@WebSocketGateway({
 cors:{origin:"*"}
})
export class RealtimeGateway{

@WebSocketServer()
server:Server;

@SubscribeMessage('notify')
handle(@MessageBody() data:any){
 this.server.emit("notification",data);
 return data;
}

}
