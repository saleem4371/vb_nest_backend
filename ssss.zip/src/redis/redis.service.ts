
import { Injectable } from '@nestjs/common';
import Redis from 'ioredis';

@Injectable()
export class RedisService{

  pub:Redis;
  sub:Redis;

  constructor(){
    this.pub=new Redis();
    this.sub=new Redis();

    this.sub.subscribe("notifications");

    this.sub.on("message",(channel,msg)=>{
      console.log("Redis message",channel,msg);
    });
  }

  publish(channel:string,message:string){
    return this.pub.publish(channel,message);
  }

}
