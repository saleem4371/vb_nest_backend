
import { Injectable } from '@nestjs/common';

@Injectable()
export class AuthService {

  login(user:any){
    return {
      message: "Login success",
      user
    };
  }

}
