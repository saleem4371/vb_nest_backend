
import { Controller, Get } from '@nestjs/common';
import { UsersService } from './users.service';

@Controller('userss')
export class UsersController{

  constructor(private usersService:UsersService){}

  @Get()
  getUsers(){
    return this.usersService.getUsers();
  }

}
