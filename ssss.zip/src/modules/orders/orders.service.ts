
import { Injectable } from '@nestjs/common';

@Injectable()
export class OrdersService{

  createOrder(data:any){
    return {
      message:"Order created",
      data
    };
  }

}
